#include <iostream>


int main (int argc, char **argv) {
    std::cout << "Replace with your solution for the main "
              << "driver program of Assignment 3\n";
    return 0;
}
