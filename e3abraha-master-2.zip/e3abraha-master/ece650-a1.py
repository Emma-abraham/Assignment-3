#!/usr/bin/env python

if __name__ == '__main__':
    print 'Replace with your solution for Assignment 1'
