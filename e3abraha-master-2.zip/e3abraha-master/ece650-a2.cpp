#include <iostream>

int main(void) {
    std::cout << "Replace with your solution for Assignment 2\n";
    return 0;
}
